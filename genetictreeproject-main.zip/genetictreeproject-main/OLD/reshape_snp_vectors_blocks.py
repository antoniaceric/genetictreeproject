# 2,3 blocks - Reshape SNP vectors for LDM model – convert 1-D embeddings to fixed 256×256 tensors

import numpy as np
import config  

# Paths (from config.py)
input_path  = config.EMBEDDING_DIR / "snp_vectors.npy"
output_path = config.EMBEDDING_DIR / "snp_images.npy"

# Target image shape & random seed
target_shape  = config.TARGET_IMAGE_SHAPE        
target_blocks = np.prod(target_shape)
np.random.seed(config.RESIZE_RANDOM_SEED)

print("Loading SNP vector data…")
snp_normalized = np.load(input_path)
n_samples, n_snps = snp_normalized.shape

# Compute 2-/3-SNP block counts
n_blocks_3 = n_snps - 2 * target_blocks     # blocks of size 3
n_blocks_2 = target_blocks - n_blocks_3     # blocks of size 2

# Build and shuffle block pattern
pattern = np.array([2] * n_blocks_2 + [3] * n_blocks_3)
np.random.shuffle(pattern)

assert len(pattern) == target_blocks
assert pattern.sum() == n_snps, "Block pattern doesn't cover all SNPs!"

# Average SNPs block-wise
snp_avg_blocks = np.empty((n_samples, target_blocks), dtype=np.float32)

start = 0
for i, block_size in enumerate(pattern):
    end = start + block_size
    snp_avg_blocks[:, i] = snp_normalized[:, start:end].mean(axis=1)
    start = end

# Reshape into 2-D image tensors and save
snp_images = snp_avg_blocks.reshape(-1, *target_shape)
np.save(output_path, snp_images)

print(
    f"SNP images saved to {output_path} with shape {snp_images.shape} "
    f"(derived from {n_snps} SNPs)."
)