"""Convert SNP image tensors to PNGs and build tensors
 with batch dimension as required for LDM

Edit paths, sizes, and N (batch dimension) in `config.py`.
"""

from pathlib import Path
from tqdm import tqdm
from PIL import Image
import numpy as np
import torch
import config

# Paths
snp_images_npy: Path = config.SNP_IMAGE_NPY
output_dir: Path    = config.LDM_IMAGE_DIR
output_dir.mkdir(parents=True, exist_ok=True)

train_txt_path: Path = config.LDM_DATASET_DIR / "train.txt"
train_txt_path.parent.mkdir(parents=True, exist_ok=True)

# Parameters
H, W        = config.TARGET_IMAGE_SHAPE
CHANNELS    = config.PNG_CHANNELS
CHANNEL_MODE = {1: "L", 3: "RGB", 4: "RGBA"}[CHANNELS]
BATCH_N     = getattr(config, "LATENT_BATCH_N", 0)           # default 0 (skip)
latent_out  = getattr(config, "LATENT_TENSOR_PT", None)

# Load data
print("Loading SNP image tensors…")
snp_images = np.load(snp_images_npy)   # (N, H, W)
print(f"Loaded SNP tensor shape: {snp_images.shape}")

if snp_images.shape[1:] != (H, W):
    raise ValueError(
        f"Tensor shape {snp_images.shape[1:]} != TARGET_IMAGE_SHAPE {(H, W)} ; "
        "re‑run reshape step or fix config.")

# Save PNGs
print("Saving PNG images…")
train_list = []

for idx, img in tqdm(enumerate(snp_images), total=len(snp_images)):
    # 0‑255 scale for PNG
    img_scaled = ((img - img.min()) / (img.max() - img.min()) * 255).astype(np.uint8)
    pil_grey   = Image.fromarray(img_scaled, mode="L")  # (W,H) = (32,32)

    if CHANNELS == 1:
        pil_out = pil_grey
    else:
        pil_out = Image.merge(CHANNEL_MODE, [pil_grey] * CHANNELS)

    fname = f"{idx:06d}.png"
    pil_out.save(output_dir / fname)
    train_list.append(f"snp_images/{fname}")

# Manifest
train_txt_path.write_text("\n".join(train_list))
print(f"PNG folder: {output_dir}  •  manifest: {train_txt_path}")

# Build latent batch tensor
if BATCH_N > 0 and latent_out is not None:
    print(f"Building latent tensor for first {BATCH_N} samples → {latent_out}")
    tensors = []
    for idx in range(min(BATCH_N, len(snp_images))):
        g = snp_images[idx]
        # scale to [-1,1] float32 and duplicate channels
        g = (g / 127.5) - 1.0  # original g is 0‑255? Actually 0‑255 only in PNG; here original range. Rescale anyway.
        t = torch.from_numpy(g).unsqueeze(0).float()        # (1,H,W)
        if CHANNELS > 1:
            t = t.repeat(CHANNELS, 1, 1)                    # (C,H,W) duplicate
        tensors.append(t.unsqueeze(0))                      # (1,C,H,W)

    batch = torch.cat(tensors, dim=0)                       # (N,C,H,W)
    latent_out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(batch, latent_out)
    print("Saved latent tensor", batch.shape)