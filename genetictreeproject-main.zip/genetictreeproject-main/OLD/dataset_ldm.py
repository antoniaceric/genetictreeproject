# Create dataset for LDM

import os
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

class SNPImageDataset(Dataset):
    def __init__(self, root_dir, train_txt, image_size=256):
        """
        Args:
            root_dir (str): Directory with all images (e.g. '/files/data/ldm_dataset').
            train_txt (str): Path to 'train.txt' listing image paths relative to root_dir.
        """
        self.root_dir = root_dir
        with open(train_txt, 'r') as f:
            self.image_paths = [line.strip() for line in f.readlines()]

        self.transform = transforms.Compose([
            transforms.Grayscale(num_output_channels=1),
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5])  # scale from [0,1] to [-1,1]
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = os.path.join(self.root_dir, self.image_paths[idx])
        image = Image.open(img_path).convert('L')  # Ensure grayscale
        return self.transform(image)
